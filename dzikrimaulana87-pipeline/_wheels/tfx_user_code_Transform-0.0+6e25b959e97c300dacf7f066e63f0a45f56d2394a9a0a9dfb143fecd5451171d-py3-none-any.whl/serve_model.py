from flask import Flask, request, jsonify
import tensorflow as tf
import numpy as np
import os

app = Flask(__name__)

# Path ke model hasil push dari komponen Pusher
# Ubah sesuai lokasi model Anda disimpan oleh pipeline
MODEL_DIR = os.path.join(os.getcwd(), 'dzikrimaulana87-pipeline', 'churn_pipeline', 'Pusher', 'model')

# Load model
model = tf.keras.models.load_model(MODEL_DIR)

@app.route('/')
def home():
    return "Churn Prediction Model is Running!"

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Input JSON: { "data": [[...], [...]] }
        input_json = request.get_json(force=True)
        input_data = np.array(input_json['data'])

        prediction = model.predict(input_data)
        prediction = prediction.tolist()  # Convert to native Python list

        return jsonify({'prediction': prediction})
    except Exception as e:
        return jsonify({'error': str(e)}), 400

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
